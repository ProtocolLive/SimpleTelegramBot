<?php
//Protocol Corporation Ltda.
//https://github.com/ProtocolLive/SimpleTelegramBot
//2022.08.27.00

const DirToken = __DIR__;
require(##DIR## . '/system/system.php');

ArgV();
if(isset($_SERVER['Cron'])):
  require(DirSystem . '/cron.php');
else:
  require(DirSystem . '/entry.php');
endif;